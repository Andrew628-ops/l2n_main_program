# Write a prompt that produces errors

List the president of the following five coiuntries: juran, zobabu,  clup, danduxs, mtham

# Rewrite the prompt so it only accepts correct data 

List five real countries and the name of their president 

# Compare both results and note the differences.

***difference note:***  the first output the model dint give an answer he noted that the country where not a recognized countries in the world saying they might be fictional or made up or misspelled names. But in the second output the model gave me the correct answer