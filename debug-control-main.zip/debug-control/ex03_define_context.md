# Place a passage inside delimiters

"""
YouTube was founded on Valentine’s Day in 2005 by three former PayPal employees: Chad Hurley, Steve Chen, and Jawed Karim. Interestingly, the platform was originally designed as a video dating site with the tagline "Tune In, Hook Up," but the founders abandoned this idea after it failed to attract users. They pivoted to a general video-sharing service after realizing there was no easy way to share videos online, an idea partially inspired by the difficulty of finding clips of the 2004 Indian Ocean tsunami and Janet Jackson’s Super Bowl halftime incident. The very first video, "Me at the zoo," was uploaded by Jawed Karim on April 23, 2005. Just 18 months after its launch, the company’s explosive growth led Google to acquire it for $1.65 billion in stock.
"""
# Add instruction

Answer using only the text inside the delimeters 

# Compare the output with and without delimiters to see the effect.

**with delimiters**

Instruction: Answer using only the text inside the delimiters.
"""YouTube was founded on Valentine’s Day in 2005 by three former PayPal employees: Chad Hurley, Steve Chen, and Jawed Karim. Interestingly, the platform was originally designed as a video dating site with the tagline "Tune In, Hook Up," but the founders abandoned this idea after it failed to attract users. They pivoted to a general video-sharing service after realizing there was no easy way to share videos online, an idea partially inspired by the difficulty of finding clips of the 2004 Indian Ocean tsunami and Janet Jackson’s Super Bowl halftime incident. The very first video, "Me at the zoo," was uploaded by Jawed Karim on April 23, 2005. Just 18 months after its launch, the company’s explosive growth led Google to acquire it for $1.65 billion in stock.""" 

***Output***

YouTube was founded on Valentine’s Day in 2005 by three former PayPal employees: Chad Hurley, Steve Chen, and Jawed Karim. Interestingly, the platform was originally designed as a video dating site with the tagline "Tune In, Hook Up," but the founders abandoned this idea after it failed to attract users. They pivoted to a general video-sharing service after realizing there was no easy way to share videos online, an idea partially inspired by the difficulty of finding clips of the 2004 Indian Ocean tsunami and Janet Jackson’s Super Bowl halftime incident. The very first video, "Me at the zoo," was uploaded by Jawed Karim on April 23, 2005. Just 18 months after its launch, the company’s explosive growth led Google to acquire it for $1.65 billion in stock.


**Without delimiters**

Instruction: Answer using only the text inside the delimiters.
YouTube was founded on Valentine’s Day in 2005 by three former PayPal employees: Chad Hurley, Steve Chen, and Jawed Karim. Interestingly, the platform was originally designed as a video dating site with the tagline "Tune In, Hook Up," but the founders abandoned this idea after it failed to attract users. They pivoted to a general video-sharing service after realizing there was no easy way to share videos online, an idea partially inspired by the difficulty of finding clips of the 2004 Indian Ocean tsunami and Janet Jackson’s Super Bowl halftime incident. The very first video, "Me at the zoo," was uploaded by Jawed Karim on April 23, 2005. Just 18 months after its launch, the company’s explosive growth led Google to acquire it for $1.65 billion in stock.

***Output***

YouTube was founded on Valentine’s Day in 2005 by three former PayPal employees: Chad Hurley, Steve Chen, and Jawed Karim. Interestingly, the platform was originally designed as a video dating site with the tagline "Tune In, Hook Up," but the founders abandoned this idea after it failed to attract users. They pivoted to a general video-sharing service after realizing there was no easy way to share videos online, an idea partially inspired by the difficulty of finding clips of the 2004 Indian Ocean tsunami and Janet Jackson’s Super Bowl halftime incident. The very first video, "Me at the zoo," was uploaded by Jawed Karim on April 23, 2005. Just 18 months after its launch, the company’s explosive growth led Google to acquire it for $1.65 billion in stock.



