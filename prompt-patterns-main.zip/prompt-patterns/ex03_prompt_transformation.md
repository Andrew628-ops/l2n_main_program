# Take a vague or under-specified prompt

write about Drug Abuse

# Transform it using instructional or comparative patterns:

Instructional: Write a 200-word explanation of drug abuse for high school learners.

# Document the improvement in clarity and usefulness of the outputs.

**Clarity:**  it looks more clear like a story all the words where plain and moves logically, no seperate sub-heading like effect, causes or prevention all the words where written plain and in paragraph, which makes it clear engaging for student. 

**Usefulness:**  its is easy for high school  student to understand, talks about causes of drug abuse, explain both short and long term effect, it describe ways it can be prevented and it is very formal and engaging for student