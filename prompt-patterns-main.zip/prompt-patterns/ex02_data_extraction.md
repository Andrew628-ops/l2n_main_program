# Choose an unstructured text

John Paul, age 20, lives in the UK works as a software engineer and loves reading and watching Podcasts

# Create a template prompt:

Extract the following field from the text: Name, Age, Location, Occupation, Hobbies. return the output in JSON format

# Validate the output and ensure consistency across multiple inputs.

the output was good and corect 

***output***
```
{
  "Name": "John Paul",
  "Age": 20,
  "Location": "UK",
  "Occupation": "Software Engineer",
  "Hobbies": ["Reading", "Watching podcasts"]
}
```