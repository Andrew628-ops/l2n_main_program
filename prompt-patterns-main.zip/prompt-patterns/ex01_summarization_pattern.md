# Write a weak prompt:

**prompt 1**

summarize on COVID-19 Virus 

**prompt 2**

summarize on Amazon

# Refine it into a reusable pattern:

**prompt 1**

summarize on COVID-19 virus in 3 bullet point, focusing on the argument and ignoring examples

**prompt 2**

summarize Amazon in 3 bullet point, focusing on the argument and ignoring examples

# Test it with at least two different inputs

**news Article**

***weak prompt***

summarize on COVID-19 Virus 

***output***

COVID-19 – Summary

COVID-19 is a contagious respiratory illness caused by the virus SARS-CoV-2. It was first identified in late 2019 in Wuhan, China, and quickly spread worldwide, leading the World Health Organization to declare a global pandemic in March 2020.

Key Points:

Transmission: Spreads mainly through respiratory droplets when an infected person coughs, sneezes, talks, or breathes.

Symptoms: Fever, cough, fatigue, loss of taste or smell, and difficulty breathing. Some people experience mild symptoms, while others may develop severe illness.

Prevention: Vaccination, hand hygiene, mask use in high-risk settings, and good ventilation help reduce spread.

Impact: Caused widespread health, economic, and social disruptions globally.

Vaccines & Treatment: Multiple vaccines were developed to reduce severe illness and death. Treatments improved over time, lowering mortality rates.

***refine prompt***

summarize on COVID-19 virus in 3 bullet point, focusing on the argument and ignoring examples

***output***

* **COVID-19** is a global respiratory illness caused by the virus **SARS-CoV-2**, first identified in 2019 and responsible for a worldwide pandemic.

* The disease spreads primarily through respiratory transmission and can range from mild symptoms to severe health complications, significantly impacting public health systems.

* The pandemic led to global health responses coordinated by organizations such as the **World Health Organization**, accelerating vaccine development, strengthening disease surveillance, and reshaping global preparedness strategies.


**Tech Company**

***weak promt***

summarize on Amazon

***output***

## Amazon – Summary

Amazon is a global technology and e-commerce company founded in 1994 by **Jeff Bezos**. It began as an online bookstore and expanded into one of the world’s largest online marketplaces.

* Operates a massive e-commerce platform connecting millions of buyers and sellers worldwide.
* Provides cloud computing services through Amazon Web Services (AWS).
* Invests in logistics, digital streaming, artificial intelligence, and smart devices.

Today, Amazon plays a major role in online retail, cloud infrastructure, and digital innovation globally.

***refined prompt***

summarize Amazon in 3 bullet point, focusing on the argument and ignoring examples

***output***

* **Amazon** is a global technology company that operates one of the world’s largest online retail platforms.

* It provides large-scale cloud computing infrastructure and digital technology services that support businesses and organizations worldwide.

* The company drives innovation in logistics, automation, and digital services, significantly influencing global commerce and technology industries.
